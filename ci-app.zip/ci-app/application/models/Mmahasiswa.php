<?php 

	class Mmahasiswa extends CI_Model {

		public function tampil_mahasiswa() {
				$query = $this->db->get('mahasiswa');
				return $query->result();
		}
	}


 ?>